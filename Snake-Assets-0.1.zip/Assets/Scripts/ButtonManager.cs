using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; 

public class ButtonManager : MonoBehaviour
{
    RaycastHit hit; 

    // Update is called once per frame
    void Update()
    {
        ButtonUI(); 
    }

    void ButtonUI() {
        if (Input.GetMouseButton(0)) {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition); 
            Physics.Raycast(ray, out hit);
            if (hit.transform.tag == "Quit") {
                Application.Quit();  
            } else if (hit.transform.tag == "Restart") {
                SceneManager.LoadScene(SceneManager.GetActiveScene().name); 
            }
        }
    }
}
