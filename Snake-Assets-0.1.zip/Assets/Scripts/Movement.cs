using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class Movement : MonoBehaviour
{
    Rigidbody rb;

    GameObject body; 

    public float speed; 
    float horizontal, vertical; 

    void Awake() {
        rb = GetComponent<Rigidbody>();
        body = transform.GetChild(0).gameObject;  
    }

    void Start() {
        Time.timeScale = 0f; 
    }

    // Update is called once per frame
    void Update()
    {   
        if (Input.GetKey(KeyCode.Space)) {
            Time.timeScale = 1.0f; 
        }
         
        Move(); 
        RotateInput(); 
    }

    // Apply a constant change in position. 
    void Move() {
        transform.position += transform.forward * speed * Time.deltaTime; 
    }

    // Rotate the player a certain angle depending on vertical and horiztonal inputs. 
    void RotateInput() {
        if (Input.GetAxisRaw("Vertical") > 0f) {
            transform.rotation = Quaternion.Euler(0f, 0f, 0f); 
        } else if (Input.GetAxisRaw("Vertical") < 0f) {
            transform.rotation = Quaternion.Euler(0f, 180f, 0f);  
        } else if (Input.GetAxisRaw("Horizontal") > 0f) {
            transform.rotation = Quaternion.Euler(0f, 90f, 0f); 
        } else if (Input.GetAxisRaw("Horizontal") < 0f) {
            transform.rotation = Quaternion.Euler(0f, -90f, 0f); 
        }
    }
}
