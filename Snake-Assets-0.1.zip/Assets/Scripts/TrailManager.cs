using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrailManager : MonoBehaviour
{
    TrailRenderer trail; 
    GameObject player;

    public GameObject bodyCollider; 
    public int gap; 
    int trailLength; 

    List<Vector3> posHistory = new List<Vector3>(); 
    List<GameObject> bodyColliders = new List<GameObject>(); 
    Vector3 colliderSpawn;

    void Awake() {
        trail = GetComponent<TrailRenderer>(); 
        player = transform.parent.gameObject; 
    }

    void Start() {
        trailLength = (int) trail.time * 5; 
        for (int i = 0; i < trailLength; i++) {
            GrowSnake(); 
        }
    }

    // Update is called once per frame
    void Update()
    {
        trailLength = (int) trail.time * 5; 
        print(trailLength); 

        // Record the player's position every frame. 
        posHistory.Insert(0, player.transform.position);
        
        int index = 0; 
        foreach(GameObject collider in bodyColliders) {
            float maxFrameRate = 1000f;
            float currentFps = 1f / Time.unscaledDeltaTime;
            float frameIndependent = Mathf.Max(1, Mathf.RoundToInt(maxFrameRate / currentFps));

            Vector3 point = posHistory[Mathf.Min(index * Mathf.RoundToInt(gap / frameIndependent), posHistory.Count - 1)];
            collider.transform.position = point; 
            index++; 
        }
    }

    public void GrowSnake() {
        GameObject collider = Instantiate(bodyCollider, transform); 
        bodyColliders.Add(collider); 
    }
}
